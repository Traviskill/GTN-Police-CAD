# GTN RP CAD — Shared Website Edition

This is a runnable full-stack starting point for the GTN RP CAD DayZ roleplay website. It replaces the browser-only prototype with an Express server, SQLite database, hashed passwords, server-side sessions, role checks, shared dispatch records, and a public crime-report form.

## Features

- Public homepage and crime reporting without citizen accounts.
- Citizen reports are stored on the server and appear in the chosen department's dispatch queue for authorized staff on other devices.
- Staff login with `admin`, `command`, and `officer` roles.
- Department-scoped access: Taliban Police command can create/manage only Taliban Police officer accounts; U.S. Embassy Police command can create/manage only U.S. Embassy Police officer accounts.
- Only the system administrator can appoint a department commander, edit the live homepage, and view the audit log.
- Only one active department command account per department is allowed.
- Officers can set Active, Busy, or Off Duty status.
- Dispatch call status updates, RP records/warrant requests, Crimes & Times, sentencing calculator, announcements, shared account management, password resets, and homepage settings.
- Password hashing (bcrypt), server-side session store, secure cookie settings in production, login/report rate limits, Helmet security headers, audit log, and SQLite persistence.

## Run locally

Requires Node.js 20 or newer.

1. Copy `.env.example` to `.env` (or set the same variables in your shell/hosting provider).
2. Set a unique admin password and a random session secret. In production, the admin password must be at least 14 characters and session secret at least 32 characters.
3. Install dependencies: `npm install`
4. Start the app: `npm start`
5. Open `http://localhost:3000`.

Linux/macOS example for a quick local run:

```sh
export ADMIN_USERNAME=admin
export ADMIN_PASSWORD='use-a-unique-password-at-least-14-chars'
export SESSION_SECRET="$(node -e "console.log(require('crypto').randomBytes(48).toString('hex'))")"
export NODE_ENV=development
npm install
npm start
```

The first start creates the administrator account from `ADMIN_USERNAME` and `ADMIN_PASSWORD` if no admin exists. Keep credentials private. Change the environment password after initial setup only if you also have a planned password rotation procedure; changing the environment variable does not automatically change an existing database account password.

### Temporary staff login

To create a temporary staff login, set `TEMP_STAFF_USERNAME`, `TEMP_STAFF_PASSWORD`, `TEMP_STAFF_DISPLAY_NAME`, and `TEMP_STAFF_DEPARTMENT` (`us` or `taliban`) in your `.env` file or hosting provider's environment settings, then restart the app. The password must be at least 12 characters. On startup, the app creates this account only if that username is not already in use. It has ordinary officer permissions only; it cannot manage accounts or edit website settings.

When the temporary access is no longer needed, sign in as an administrator or the relevant department command, open **Manage Accounts**, and disable the account. The environment settings do not overwrite an existing account or reset its password. Keep the temporary credentials private and do not commit your `.env` file.

## Create the department command accounts

1. Sign in with the system administrator.
2. Open **Manage Accounts**.
3. Create one account with role **Department Command** and department **Taliban Police**.
4. Create another with role **Department Command** and department **U.S. Embassy Police**.
5. Commanders sign in and create officer accounts for their own department. The department field is locked for commanders, and server-side checks enforce this restriction.

Passwords set when creating/resetting an account must be at least 12 characters. Give temporary passwords privately and have officers change them through your organization's trusted password-management process. This version does not yet have a self-service password-change screen or email reset flow.

## Hosting and domain

This package does not buy a domain or publish itself automatically. Deploy it to a Node.js host that supports persistent disk storage (for the SQLite database and session store), set the environment variables in the host dashboard, and enable HTTPS. Set `NODE_ENV=production`, `SESSION_SECRET`, `ADMIN_USERNAME`, and `ADMIN_PASSWORD`. Use a persistent volume for `DATABASE_FILE` and back it up regularly. Point your registered custom domain to the host using the DNS records supplied by that provider.

For multi-instance/cloud hosting, replace SQLite with a managed database and use a shared session store. Do not deploy to an ephemeral filesystem if you need records to persist. Restrict database backups and admin access.

## Important limitations / deployment checklist

- This is a functional, self-hostable starting application, but it has not been deployed or penetration-tested. You still need to choose a host, set secrets, configure a domain/HTTPS, and test it with your server's rules before public use.
- Use fictional roleplay data only. Do not enter real emergency reports, sensitive personal information, or real-world law-enforcement records.
- Public reports are rate-limited but public forms can still receive spam; consider CAPTCHA or a moderation queue if the site is widely exposed.
- For a production release, consider adding CSRF tokens, a self-service password change flow, automated backups, monitoring, and formal security testing.
- The default criminal-code entries are fictional examples and should be approved/customized by server leadership.

## Render deployment (persistent SQLite storage)

A `render.yaml` Blueprint is included as a starting configuration. It requests a persistent disk, so it uses a paid Render web-service plan; Render's free web services do not provide persistent disks for SQLite. Before creating the service, review the plan and current pricing in Render. During setup, enter private values for `ADMIN_PASSWORD` (at least 14 characters), `TEMP_STAFF_USERNAME` (3–50 letters/numbers/dot/underscore/hyphen), and `TEMP_STAFF_PASSWORD` (at least 12 characters). `SESSION_SECRET` is generated by the Blueprint. Never commit actual secrets to GitHub.

After deployment, check `/api/health` on the service URL. Then open the homepage, sign in with the admin credentials, create department command accounts, and test public reporting and dispatch with fictional test data. The temporary staff account is a normal officer account only. If the username already exists in the database, startup intentionally does not replace that account or reset its password.
